import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:flutter_compass/flutter_compass.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:salati_app/hadith_data.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tz.initializeTimeZones();
  await NotificationService.instance.init();
  runApp(const SalatiApp());
}

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();
  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    const androidInit = AndroidInitializationSettings('@mipmap/launcher_icon');
    const initSettings = InitializationSettings(android: androidInit);
    await _plugin.initialize(initSettings);
  }

  Future<void> requestPermissions() async {
    await Permission.notification.request();
    await Permission.scheduleExactAlarm.request();
    await Permission.ignoreBatteryOptimizations.request();
  }

  Future<void> schedulePrayerNotification({
    required int id,
    required String title,
    required String body,
    required DateTime scheduledTime,
  }) async {
    if (scheduledTime.isBefore(DateTime.now())) return;
    final tzTime = tz.TZDateTime.from(scheduledTime, tz.local);
    const androidDetails = AndroidNotificationDetails(
      'salati_azan_channel_v2',
      'تنبيهات الأذان والصلوات',
      channelDescription: 'تنبيهات أوقات الصلاة والأذان في تطبيق صلاتي',
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
      fullScreenIntent: true,
    );
    await _plugin.zonedSchedule(
      id,
      title,
      body,
      tzTime,
      const NotificationDetails(android: androidDetails),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  Future<void> cancelAll() async {
    await _plugin.cancelAll();
  }
}

class SalatiApp extends StatefulWidget {
  const SalatiApp({super.key});

  @override
  State<SalatiApp> createState() => _SalatiAppState();
}

class _SalatiAppState extends State<SalatiApp> {
  bool _isDarkMode = false;

  @override
  void initState() {
    super.initState();
    _loadTheme();
  }

  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isDarkMode = prefs.getBool('dark_mode') ?? false;
    });
  }

  void _toggleTheme(bool val) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('dark_mode', val);
    setState(() {
      _isDarkMode = val;
    });
  }

  @override
  Widget build(BuildContext context) {
    final baseLight = ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF0E5A47),
        primary: const Color(0xFF0E5A47),
        secondary: const Color(0xFFC89B3C),
        surface: const Color(0xFFF6F4EE),
      ),
      scaffoldBackgroundColor: const Color(0xFFF6F4EE),
      textTheme: GoogleFonts.cairoTextTheme(),
    );

    final baseDark = ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(
        brightness: Brightness.dark,
        seedColor: const Color(0xFF147A61),
        primary: const Color(0xFF22A684),
        secondary: const Color(0xFFD9AE4E),
        surface: const Color(0xFF121816),
      ),
      scaffoldBackgroundColor: const Color(0xFF0D1210),
      textTheme: GoogleFonts.cairoTextTheme(ThemeData.dark().textTheme),
    );

    return MaterialApp(
      title: 'صلاتي',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: _isDarkMode ? baseDark : baseLight,
      home: MainNavigationScreen(
        isDarkMode: _isDarkMode,
        onToggleTheme: _toggleTheme,
      ),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  final bool isDarkMode;
  final ValueChanged<bool> onToggleTheme;

  const MainNavigationScreen({
    super.key,
    required this.isDarkMode,
    required this.onToggleTheme,
  });

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePrayerScreen(
        isDarkMode: widget.isDarkMode,
        onToggleTheme: widget.onToggleTheme,
      ),
      const QuranScreen(),
      const AzkarAndHadithScreen(),
      const QiblaAndTasbihScreen(),
    ];

    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: pages,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (idx) => setState(() => _selectedIndex = idx),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.mosque_outlined),
            selectedIcon: Icon(Icons.mosque),
            label: 'المواقيت',
          ),
          NavigationDestination(
            icon: Icon(Icons.menu_book_outlined),
            selectedIcon: Icon(Icons.menu_book),
            label: 'القرآن',
          ),
          NavigationDestination(
            icon: Icon(Icons.auto_stories_outlined),
            selectedIcon: Icon(Icons.auto_stories),
            label: 'الأذكار والحديث',
          ),
          NavigationDestination(
            icon: Icon(Icons.explore_outlined),
            selectedIcon: Icon(Icons.explore),
            label: 'القبلة والسبحة',
          ),
        ],
      ),
    );
  }
}

class HomePrayerScreen extends StatefulWidget {
  final bool isDarkMode;
  final ValueChanged<bool> onToggleTheme;

  const HomePrayerScreen({
    super.key,
    required this.isDarkMode,
    required this.onToggleTheme,
  });

  @override
  State<HomePrayerScreen> createState() => _HomePrayerScreenState();
}

class _HomePrayerScreenState extends State<HomePrayerScreen> {
  String _cityName = 'حلب، سوريا';
  String _hijriDate = '';
  double _lat = 36.2021;
  double _lng = 37.1343;
  int _calculationMethod = 4; // Umm Al-Qura / Syrian standard
  int _madhab = 0; // 0 = Shafi/Standard, 1 = Hanafi
  bool _isLoading = false;
  bool _isAzanPlaying = false;
  final AudioPlayer _audioPlayer = AudioPlayer();
  Timer? _countdownTimer;
  String _nextPrayerName = 'الفجر';
  Duration _remaining = Duration.zero;

  Map<String, String> _prayerTimes = {
    'Fajr': '04:45',
    'Sunrise': '06:15',
    'Dhuhr': '12:15',
    'Asr': '15:25',
    'Maghrib': '18:05',
    'Isha': '19:25',
  };

  Map<String, bool> _azanEnabled = {
    'Fajr': true,
    'Dhuhr': true,
    'Asr': true,
    'Maghrib': true,
    'Isha': true,
  };

  final Map<String, String> _arabicNames = const {
    'Fajr': 'الفجر',
    'Sunrise': 'الشروق',
    'Dhuhr': 'الظهر',
    'Asr': 'العصر',
    'Maghrib': 'المغرب',
    'Isha': 'العشاء',
  };

  @override
  void initState() {
    super.initState();
    _initData();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      _updateNextPrayer();
    });
    _audioPlayer.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _isAzanPlaying = false);
    });
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    _audioPlayer.dispose();
    super.dispose();
  }

  Future<void> _initData() async {
    await NotificationService.instance.requestPermissions();
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _cityName = prefs.getString('city_name') ?? 'حلب، سوريا';
      _lat = prefs.getDouble('lat') ?? 36.2021;
      _lng = prefs.getDouble('lng') ?? 37.1343;
      _calculationMethod = prefs.getInt('calc_method') ?? 4;
      _madhab = prefs.getInt('madhab') ?? 0;
      for (final key in _azanEnabled.keys) {
        _azanEnabled[key] = prefs.getBool('azan_$key') ?? true;
      }
      final savedTimes = prefs.getString('saved_prayer_times');
      if (savedTimes != null) {
        final decoded = jsonDecode(savedTimes) as Map<String, dynamic>;
        _prayerTimes = decoded.map((k, v) => MapEntry(k, v.toString()));
      }
      _hijriDate = prefs.getString('hijri_date') ?? '';
    });
    _updateNextPrayer();
    await _fetchPrayerTimes();
  }

  Future<void> _fetchPrayerTimes() async {
    setState(() => _isLoading = true);
    try {
      final now = DateTime.now();
      final dateStr =
          '${now.day.toString().padLeft(2, '0')}-${now.month.toString().padLeft(2, '0')}-${now.year}';
      final url = Uri.parse(
        'https://api.aladhan.com/v1/timings/$dateStr?latitude=$_lat&longitude=$_lng&method=$_calculationMethod&school=$_madhab',
      );
      final response = await http.get(url).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final timings = data['data']['timings'] as Map<String, dynamic>;
        final hijri = data['data']['date']['hijri'];
        final hijriText =
            '${hijri['day']} ${hijri['month']['ar']} ${hijri['year']} هـ';

        final updated = <String, String>{
          'Fajr': timings['Fajr'].toString().split(' ').first,
          'Sunrise': timings['Sunrise'].toString().split(' ').first,
          'Dhuhr': timings['Dhuhr'].toString().split(' ').first,
          'Asr': timings['Asr'].toString().split(' ').first,
          'Maghrib': timings['Maghrib'].toString().split(' ').first,
          'Isha': timings['Isha'].toString().split(' ').first,
        };

        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('saved_prayer_times', jsonEncode(updated));
        await prefs.setString('hijri_date', hijriText);

        setState(() {
          _prayerTimes = updated;
          _hijriDate = hijriText;
        });
        _updateNextPrayer();
        await _scheduleAllNotifications();
      }
    } catch (_) {
      // Keep cached prayer times offline
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _updateLocationGPS() async {
    setState(() => _isLoading = true);
    try {
      LocationPermission perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('يرجى تفعيل صلاحية الموقع GPS')),
          );
        }
        return;
      }

      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      );
      String newCity = '${pos.latitude.toStringAsFixed(2)}, ${pos.longitude.toStringAsFixed(2)}';
      try {
        final placemarks = await placemarkFromCoordinates(pos.latitude, pos.longitude);
        if (placemarks.isNotEmpty) {
          final p = placemarks.first;
          final city = p.locality ?? p.subAdministrativeArea ?? p.administrativeArea ?? '';
          final country = p.country ?? '';
          if (city.isNotEmpty || country.isNotEmpty) {
            newCity = [city, country].where((e) => e.isNotEmpty).join('، ');
          }
        }
      } catch (_) {}

      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble('lat', pos.latitude);
      await prefs.setDouble('lng', pos.longitude);
      await prefs.setString('city_name', newCity);

      setState(() {
        _lat = pos.latitude;
        _lng = pos.longitude;
        _cityName = newCity;
      });
      await _fetchPrayerTimes();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر تحديد الموقع، تأكد من تشغيل GPS')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  DateTime _parseTodayTime(String hhmm) {
    final parts = hhmm.split(':');
    final now = DateTime.now();
    return DateTime(
      now.year,
      now.month,
      now.day,
      int.parse(parts[0]),
      int.parse(parts[1]),
    );
  }

  void _updateNextPrayer() {
    final now = DateTime.now();
    final order = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
    for (final key in order) {
      final t = _parseTodayTime(_prayerTimes[key]!);
      if (t.isAfter(now)) {
        if (mounted) {
          setState(() {
            _nextPrayerName = _arabicNames[key]!;
            _remaining = t.difference(now);
          });
        }
        return;
      }
    }
    final tomorrowFajr = _parseTodayTime(_prayerTimes['Fajr']!).add(const Duration(days: 1));
    if (mounted) {
      setState(() {
        _nextPrayerName = 'الفجر';
        _remaining = tomorrowFajr.difference(now);
      });
    }
  }

  Future<void> _scheduleAllNotifications() async {
    await NotificationService.instance.cancelAll();
    int id = 100;
    for (final key in _azanEnabled.keys) {
      if (_azanEnabled[key] == true && _prayerTimes.containsKey(key)) {
        final dt = _parseTodayTime(_prayerTimes[key]!);
        await NotificationService.instance.schedulePrayerNotification(
          id: id++,
          title: 'حان الآن موعد أذان ${_arabicNames[key]}',
          body: 'حيّ على الصلاة • حسب توقيت $_cityName',
          scheduledTime: dt,
        );
      }
    }
  }

  Future<void> _toggleAzanSound() async {
    if (_isAzanPlaying) {
      await _audioPlayer.stop();
      setState(() => _isAzanPlaying = false);
    } else {
      await _audioPlayer.play(AssetSource('azan.mp3'));
      setState(() => _isAzanPlaying = true);
    }
  }

  String _formatDuration(Duration d) {
    final h = d.inHours.toString().padLeft(2, '0');
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  void _openSettingsSheet() {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModalState) {
            return Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'إعدادات المواقيت والمظهر',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  SwitchListTile(
                    title: const Text('الوضع الليلي الداكن'),
                    secondary: const Icon(Icons.dark_mode),
                    value: widget.isDarkMode,
                    onChanged: (v) {
                      widget.onToggleTheme(v);
                      setModalState(() {});
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.calculate),
                    title: const Text('طريقة الحساب الفلكي'),
                    trailing: DropdownButton<int>(
                      value: _calculationMethod,
                      items: const [
                        DropdownMenuItem(value: 4, child: Text('أم القرى')),
                        DropdownMenuItem(value: 3, child: Text('رابطة العالم الإسلامي')),
                        DropdownMenuItem(value: 5, child: Text('الهيئة المصرية')),
                      ],
                      onChanged: (val) async {
                        if (val == null) return;
                        final prefs = await SharedPreferences.getInstance();
                        await prefs.setInt('calc_method', val);
                        setState(() => _calculationMethod = val);
                        setModalState(() {});
                        _fetchPrayerTimes();
                      },
                    ),
                  ),
                  ListTile(
                    leading: const Icon(Icons.access_time),
                    title: const Text('المذهب الفقهي (العصر)'),
                    trailing: DropdownButton<int>(
                      value: _madhab,
                      items: const [
                        DropdownMenuItem(value: 0, child: Text('الجمهور')),
                        DropdownMenuItem(value: 1, child: Text('الحنفي')),
                      ],
                      onChanged: (val) async {
                        if (val == null) return;
                        final prefs = await SharedPreferences.getInstance();
                        await prefs.setInt('madhab', val);
                        setState(() => _madhab = val);
                        setModalState(() {});
                        _fetchPrayerTimes();
                      },
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('صلاتي', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.settings),
          onPressed: _openSettingsSheet,
        ),
        actions: [
          IconButton(
            icon: _isLoading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.my_location),
            tooltip: 'تحديث الموقع GPS',
            onPressed: _updateLocationGPS,
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _fetchPrayerTimes,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [cs.primary, cs.primary.withOpacity(0.82)],
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                ),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: cs.primary.withOpacity(0.28),
                    blurRadius: 14,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.location_on, color: Colors.white70, size: 18),
                          const SizedBox(width: 4),
                          Text(
                            _cityName,
                            style: const TextStyle(color: Colors.white, fontSize: 14),
                          ),
                        ],
                      ),
                      if (_hijriDate.isNotEmpty)
                        Text(
                          _hijriDate,
                          style: const TextStyle(color: Colors.white70, fontSize: 12),
                        ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'الصلاة القادمة: $_nextPrayerName',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    _formatDuration(_remaining),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 34,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 14),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: cs.primary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    onPressed: _toggleAzanSound,
                    icon: Icon(_isAzanPlaying ? Icons.stop : Icons.volume_up),
                    label: Text(_isAzanPlaying ? 'إيقاف صوت الأذان' : 'تجربة صوت الأذان'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            ..._prayerTimes.entries.map((entry) {
              final key = entry.key;
              final time = entry.value;
              final name = _arabicNames[key] ?? key;
              final isNext = name == _nextPrayerName;
              final hasSwitch = _azanEnabled.containsKey(key);

              return Card(
                elevation: isNext ? 3 : 0.5,
                margin: const EdgeInsets.only(bottom: 10),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                  side: isNext
                      ? BorderSide(color: cs.secondary, width: 1.5)
                      : BorderSide.none,
                ),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: cs.primary.withOpacity(0.12),
                    child: Icon(Icons.access_time_filled, color: cs.primary),
                  ),
                  title: Text(
                    name,
                    style: TextStyle(
                      fontWeight: isNext ? FontWeight.bold : FontWeight.w600,
                      fontSize: 16,
                    ),
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        time,
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                          color: cs.primary,
                        ),
                      ),
                      if (hasSwitch) ...[
                        const SizedBox(width: 8),
                        IconButton(
                          icon: Icon(
                            _azanEnabled[key]!
                                ? Icons.notifications_active
                                : Icons.notifications_off_outlined,
                            color: _azanEnabled[key]! ? cs.secondary : Colors.grey,
                          ),
                          onPressed: () async {
                            final prefs = await SharedPreferences.getInstance();
                            final newVal = !(_azanEnabled[key]!);
                            await prefs.setBool('azan_$key', newVal);
                            setState(() => _azanEnabled[key] = newVal);
                            await _scheduleAllNotifications();
                          },
                        ),
                      ],
                    ],
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}

class QuranScreen extends StatefulWidget {
  const QuranScreen({super.key});

  @override
  State<QuranScreen> createState() => _QuranScreenState();
}

class _QuranScreenState extends State<QuranScreen> {
  List<dynamic> _surahs = [];
  List<dynamic> _filtered = [];
  bool _loading = true;
  int _lastSurahNumber = 1;
  String _lastSurahName = 'سورة الفاتحة';

  @override
  void initState() {
    super.initState();
    _loadLastRead();
    _fetchSurahs();
  }

  Future<void> _loadLastRead() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _lastSurahNumber = prefs.getInt('last_surah_num') ?? 1;
      _lastSurahName = prefs.getString('last_surah_name') ?? 'سورة الفاتحة';
    });
  }

  Future<void> _fetchSurahs() async {
    final prefs = await SharedPreferences.getInstance();
    final cached = prefs.getString('cached_surahs_list');
    if (cached != null) {
      final list = jsonDecode(cached) as List<dynamic>;
      setState(() {
        _surahs = list;
        _filtered = list;
        _loading = false;
      });
    }
    try {
      final res = await http
          .get(Uri.parse('https://api.alquran.cloud/v1/surah'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body)['data'] as List<dynamic>;
        await prefs.setString('cached_surahs_list', jsonEncode(data));
        if (mounted) {
          setState(() {
            _surahs = data;
            _filtered = data;
            _loading = false;
          });
        }
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _filter(String q) {
    setState(() {
      _filtered = _surahs
          .where((s) =>
              s['name'].toString().contains(q) ||
              s['number'].toString() == q.trim())
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('القرآن الكريم', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: Card(
              color: cs.primary.withOpacity(0.1),
              child: ListTile(
                leading: Icon(Icons.bookmark, color: cs.primary),
                title: const Text('متابعة الختمة (آخر قراءة)'),
                subtitle: Text(_lastSurahName),
                trailing: ElevatedButton(
                  onPressed: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => SurahDetailScreen(
                          surahNumber: _lastSurahNumber,
                          surahName: _lastSurahName,
                        ),
                      ),
                    );
                    _loadLastRead();
                  },
                  child: const Text('متابعة'),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            child: TextField(
              onChanged: _filter,
              decoration: InputDecoration(
                hintText: 'ابحث عن اسم السورة أو رقمها...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                    itemCount: _filtered.length,
                    itemBuilder: (ctx, idx) {
                      final s = _filtered[idx];
                      final rev = s['revelationType'] == 'Meccan' ? 'مكية' : 'مدنية';
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor: cs.primary,
                          foregroundColor: Colors.white,
                          child: Text('${s['number']}'),
                        ),
                        title: Text(
                          s['name'],
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                        ),
                        subtitle: Text('$rev • ${s['numberOfAyahs']} آية'),
                        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                        onTap: () async {
                          final prefs = await SharedPreferences.getInstance();
                          await prefs.setInt('last_surah_num', s['number']);
                          await prefs.setString('last_surah_name', s['name']);
                          if (!mounted) return;
                          await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => SurahDetailScreen(
                                surahNumber: s['number'],
                                surahName: s['name'],
                              ),
                            ),
                          );
                          _loadLastRead();
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class SurahDetailScreen extends StatefulWidget {
  final int surahNumber;
  final String surahName;

  const SurahDetailScreen({
    super.key,
    required this.surahNumber,
    required this.surahName,
  });

  @override
  State<SurahDetailScreen> createState() => _SurahDetailScreenState();
}

class _SurahDetailScreenState extends State<SurahDetailScreen> {
  List<dynamic> _ayahs = [];
  bool _loading = true;
  double _fontSize = 24;

  @override
  void initState() {
    super.initState();
    _loadAyahs();
  }

  Future<void> _loadAyahs() async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'surah_text_${widget.surahNumber}';
    final cached = prefs.getString(key);
    if (cached != null) {
      setState(() {
        _ayahs = jsonDecode(cached) as List<dynamic>;
        _loading = false;
      });
      return;
    }
    try {
      final res = await http
          .get(Uri.parse('https://api.alquran.cloud/v1/surah/${widget.surahNumber}/quran-uthmani'))
          .timeout(const Duration(seconds: 12));
      if (res.statusCode == 200) {
        final ayahs = jsonDecode(res.body)['data']['ayahs'] as List<dynamic>;
        await prefs.setString(key, jsonEncode(ayahs));
        if (mounted) {
          setState(() {
            _ayahs = ayahs;
            _loading = false;
          });
        }
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.surahName),
        actions: [
          IconButton(
            icon: const Icon(Icons.text_decrease),
            onPressed: () => setState(() => _fontSize = math.max(18, _fontSize - 2)),
          ),
          IconButton(
            icon: const Icon(Icons.text_increase),
            onPressed: () => setState(() => _fontSize = math.min(36, _fontSize + 2)),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _ayahs.isEmpty
              ? const Center(child: Text('يرجى الاتصال بالإنترنت لتحميل السورة لأول مرة'))
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      if (widget.surahNumber != 1 && widget.surahNumber != 9)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 16),
                          child: Text(
                            'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
                            style: GoogleFonts.amiri(
                              fontSize: _fontSize + 2,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      SelectableText.rich(
                        TextSpan(
                          children: _ayahs.map((a) {
                            String text = a['text'].toString();
                            if (widget.surahNumber != 1 && a['numberInSurah'] == 1) {
                              text = text.replaceFirst('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', '').trim();
                            }
                            return TextSpan(
                              text: '$text ﴿${a['numberInSurah']}﴾ ',
                              style: GoogleFonts.amiri(
                                fontSize: _fontSize,
                                height: 2.0,
                              ),
                            );
                          }).toList(),
                        ),
                        textAlign: TextAlign.justify,
                      ),
                    ],
                  ),
                ),
    );
  }
}

class AzkarAndHadithScreen extends StatefulWidget {
  const AzkarAndHadithScreen({super.key});

  @override
  State<AzkarAndHadithScreen> createState() => _AzkarAndHadithScreenState();
}

class _AzkarAndHadithScreenState extends State<AzkarAndHadithScreen> {
  final List<Map<String, dynamic>> _azkar = [
    {
      'category': 'أذكار الصباح',
      'text': 'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَـهَ إِلاَّ اللهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.',
      'count': 1,
    },
    {
      'category': 'أذكار الصباح',
      'text': 'اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ وَإِلَيْكَ النُّشُورُ.',
      'count': 1,
    },
    {
      'category': 'أذكار الصباح',
      'text': 'سُبْحَانَ اللهِ وَبِحَمْدِهِ: عَدَدَ خَلْقِهِ، وَرِضَا نَفْسِهِ، وَزِنَةَ عَرْشِهِ، وَمِدَادَ كَلِمَاتِهِ.',
      'count': 3,
    },
    {
      'category': 'أذكار المساء',
      'text': 'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَـهَ إِلاَّ اللهُ وَحْدَهُ لاَ شَرِيكَ لَهُ.',
      'count': 1,
    },
    {
      'category': 'أذكار المساء',
      'text': 'بِسْمِ اللهِ الَّذِي لاَ يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الأَرْضِ وَلاَ فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ.',
      'count': 3,
    },
    {
      'category': 'أذكار بعد الصلاة',
      'text': 'أَسْتَغْفِرُ اللهَ (ثَلاَثاً) اللَّهُمَّ أَنْتَ السَّلاَمُ، وَمِنْكَ السَّلاَمُ، تَبَارَكْتَ يَا ذَا الْجَلاَلِ وَالإِكْرَامِ.',
      'count': 1,
    },
  ];

  late List<int> _remainingCounts;

  @override
  void initState() {
    super.initState();
    _remainingCounts = _azkar.map((e) => e['count'] as int).toList();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('الأذكار والأحاديث', style: TextStyle(fontWeight: FontWeight.bold)),
          centerTitle: true,
          bottom: const TabBar(
            tabs: [
              Tab(text: 'حصن المسلم (الأذكار)'),
              Tab(text: 'أحاديث وقصص نبوية'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _azkar.length,
              itemBuilder: (ctx, idx) {
                final item = _azkar[idx];
                final rem = _remainingCounts[idx];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Chip(label: Text(item['category'])),
                            IconButton(
                              icon: const Icon(Icons.share, size: 20),
                              onPressed: () => Share.share(item['text']),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          item['text'],
                          style: const TextStyle(fontSize: 17, height: 1.7),
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: rem == 0 ? Colors.green : cs.primary,
                              foregroundColor: Colors.white,
                            ),
                            onPressed: () {
                              if (rem > 0) {
                                HapticFeedback.lightImpact();
                                setState(() => _remainingCounts[idx]--);
                              }
                            },
                            child: Text(rem == 0 ? 'تم الذكر ✓' : 'التكرار المتبقي: $rem'),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: hadithAndStoriesList.length,
              itemBuilder: (ctx, idx) {
                final h = hadithAndStoriesList[idx];
                return Card(
                  margin: const EdgeInsets.only(bottom: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                h.title,
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: cs.primary,
                                ),
                              ),
                            ),
                            Chip(label: Text(h.category)),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Text(
                          h.text,
                          style: const TextStyle(fontSize: 16, height: 1.7),
                        ),
                        const Divider(height: 24),
                        Text(
                          'المصدر: ${h.source}',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            color: cs.secondary,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'العبرة المستفادة: ${h.lesson}',
                          style: const TextStyle(fontSize: 14),
                        ),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: IconButton(
                            icon: const Icon(Icons.share),
                            onPressed: () => Share.share('${h.title}\n\n${h.text}\n(${h.source})'),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class QiblaAndTasbihScreen extends StatefulWidget {
  const QiblaAndTasbihScreen({super.key});

  @override
  State<QiblaAndTasbihScreen> createState() => _QiblaAndTasbihScreenState();
}

class _QiblaAndTasbihScreenState extends State<QiblaAndTasbihScreen> {
  int _tasbihCount = 0;
  String _selectedZikr = 'سبحان الله';
  final List<String> _zikrOptions = [
    'سبحان الله',
    'الحمد لله',
    'لا إله إلا الله',
    'الله أكبر',
    'أستغفر الله العظيم',
    'اللهم صلِّ وسلم على نبينا محمد',
  ];

  @override
  void initState() {
    super.initState();
    _loadTasbih();
  }

  Future<void> _loadTasbih() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _tasbihCount = prefs.getInt('tasbih_count') ?? 0;
    });
  }

  Future<void> _incrementTasbih() async {
    HapticFeedback.mediumImpact();
    final prefs = await SharedPreferences.getInstance();
    setState(() => _tasbihCount++);
    await prefs.setInt('tasbih_count', _tasbihCount);
  }

  Future<void> _resetTasbih() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _tasbihCount = 0);
    await prefs.setInt('tasbih_count', 0);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('القبلة والسبحة', style: TextStyle(fontWeight: FontWeight.bold)),
          centerTitle: true,
          bottom: const TabBar(
            tabs: [
              Tab(text: 'المسبحة الإلكترونية'),
              Tab(text: 'اتجاه القبلة'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  DropdownButtonFormField<String>(
                    value: _selectedZikr,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    items: _zikrOptions
                        .map((z) => DropdownMenuItem(value: z, child: Text(z)))
                        .toList(),
                    onChanged: (v) {
                      if (v != null) setState(() => _selectedZikr = v);
                    },
                  ),
                  const SizedBox(height: 36),
                  GestureDetector(
                    onTap: _incrementTasbih,
                    child: Container(
                      width: 210,
                      height: 210,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [cs.primary, cs.secondary],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: cs.primary.withOpacity(0.35),
                            blurRadius: 20,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              '$_tasbihCount',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 48,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const Text(
                              'اضغط للتسبيح',
                              style: TextStyle(color: Colors.white70, fontSize: 14),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 28),
                  OutlinedButton.icon(
                    onPressed: _resetTasbih,
                    icon: const Icon(Icons.refresh),
                    label: const Text('تصفير العداد'),
                  ),
                ],
              ),
            ),
            StreamBuilder<CompassEvent>(
              stream: FlutterCompass.events,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                final direction = snapshot.data?.heading;
                if (direction == null) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'مستشعر البوصلة غير متوفر أو يحتاج إلى معايرة بتحريك الهاتف على شكل رقم 8.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
                  );
                }
                // Qibla angle from Aleppo/Syria (~165 degrees SE)
                const qiblaAngle = 165.0;
                final angleRad = (qiblaAngle - direction) * (math.pi / 180);

                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        'وجّه رأس السهم نحو الكعبة المشرفة',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 28),
                      Container(
                        width: 240,
                        height: 240,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: cs.primary, width: 4),
                        ),
                        child: Transform.rotate(
                          angle: angleRad,
                          child: Icon(
                            Icons.navigation,
                            size: 110,
                            color: cs.secondary,
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      Text(
                        'زاوية البوصلة: ${direction.toStringAsFixed(0)}°',
                        style: const TextStyle(fontSize: 16),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
