import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SalatiApp());
}

class SalatiApp extends StatelessWidget {
  const SalatiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'صلاتي',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0F1E1A),
        primaryColor: const Color(0xFF1B4332),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF2D6A4F),
          surface: Color(0xFF162D25),
        ),
      ),
      home: const MainNavigationScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    HomeScreen(),
    DuasScreen(),
    SebhaScreen(),
    WhatsNewScreen(),
    SettingsScreen(),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkXiaomiStartupDialog();
    });
  }

  Future<void> _checkXiaomiStartupDialog() async {
    final prefs = await SharedPreferences.getInstance();
    bool isConfigured = prefs.getBool('permissions_configured') ?? false;
    if (!isConfigured && mounted) {
      _showXiaomiStartupDialog(context);
    }
  }

  void _showXiaomiStartupDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF183329),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.security, color: Colors.greenAccent),
            SizedBox(width: 8),
            Text(
              'تفعيل أذان الخلفية والجيب',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'لضمان انطلاق صوت الأذان في موعده وهاتفك في جيبك والشاشة مغلقة، اضغط على الأزرار الثلاثة لتفعيل الصلاحيات:',
              style: TextStyle(fontSize: 13, color: Colors.white70),
            ),
            const SizedBox(height: 14),
            _buildXiaomiPermButton(
              icon: Icons.notifications_active,
              title: '1. تفعيل الإشعارات والصوت',
              onTap: () => _invokeNativeSetting('openNotificationSettings'),
            ),
            const SizedBox(height: 8),
            _buildXiaomiPermButton(
              icon: Icons.battery_charging_full,
              title: '2. البطارية (اختر: لا توجد قيود)',
              onTap: () => _invokeNativeSetting('openBatterySettings'),
            ),
            const SizedBox(height: 8),
            _buildXiaomiPermButton(
              icon: Icons.settings_suggest,
              title: '3. تفعيل التشغيل التلقائي',
              onTap: () => _invokeNativeSetting('openAutostartSettings'),
            ),
          ],
        ),
        actions: [
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.greenAccent.shade700,
              foregroundColor: Colors.white,
              minimumSize: const Size.fromHeight(45),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.setBool('permissions_configured', true);
              if (ctx.mounted) Navigator.pop(ctx);
            },
            icon: const Icon(Icons.check_circle),
            label: const Text('تم الضبط .. حفظ ومتابعة'),
          )
        ],
      ),
    );
  }

  static Future<void> _invokeNativeSetting(String method) async {
    const channel = MethodChannel('com.salati.app/settings');
    try {
      await channel.invokeMethod(method);
    } catch (_) {}
  }

  Widget _buildXiaomiPermButton({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return OutlinedButton.icon(
      style: OutlinedButton.styleFrom(
        foregroundColor: Colors.white,
        side: const BorderSide(color: Colors.white24),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        alignment: Alignment.centerRight,
      ),
      onPressed: onTap,
      icon: Icon(icon, color: Colors.amberAccent, size: 20),
      label: Text(title, style: const TextStyle(fontSize: 13)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF0F1E1A),
        indicatorColor: const Color(0xFF2D6A4F),
        selectedIndex: _currentIndex,
        onDestinationSelected: (idx) => setState(() => _currentIndex = idx),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.mosque), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.menu_book), label: 'أدعية'),
          NavigationDestination(icon: Icon(Icons.fingerprint), label: 'التسبيح'),
          NavigationDestination(icon: Icon(Icons.campaign), label: 'ما الجديد'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'الإعدادات'),
        ],
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('صلاتي'),
        backgroundColor: const Color(0xFF162D25),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF162D25),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.greenAccent.shade700),
            ),
            child: const Column(
              children: [
                Text('متبقي لصلاة الظهر', style: TextStyle(fontSize: 15, color: Colors.white70)),
                SizedBox(height: 8),
                Text('00:12:25', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.greenAccent)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _prayerItem('صلاة الفجر', '05:29 ص'),
          _prayerItem('الشروق', '06:45 ص'),
          _prayerItem('صلاة الظهر', '12:16 م'),
          _prayerItem('صلاة العصر', '03:21 م'),
          _prayerItem('صلاة المغرب', '05:46 م'),
          _prayerItem('صلاة العشاء', '07:15 م'),
        ],
      ),
    );
  }

  static Widget _prayerItem(String name, String time) {
    return Card(
      color: const Color(0xFF1B382E),
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
        trailing: Text(time, style: const TextStyle(color: Colors.greenAccent, fontSize: 16)),
      ),
    );
  }
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  static final AudioPlayer _player = AudioPlayer();
  bool _isAutoAzanEnabled = true;
  bool _isPlaying = false;
  Timer? _testTimer;
  int _secondsLeft = 0;

  @override
  void initState() {
    super.initState();
    _player.onPlayerStateChanged.listen((state) {
      if (mounted) setState(() => _isPlaying = (state == PlayerState.playing));
    });
  }

  Future<void> _playAzan() async {
    await _player.stop();
    await _player.play(AssetSource('azan.mp3'));
  }

  Future<void> _stopAzan() async {
    await _player.stop();
    _testTimer?.cancel();
    if (mounted) setState(() => _secondsLeft = 0);
  }

  void _start20SecTest() {
    setState(() => _secondsLeft = 20);
    _testTimer?.cancel();
    _testTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_secondsLeft <= 1) {
        timer.cancel();
        _playAzan();
        if (mounted) setState(() => _secondsLeft = 0);
      } else {
        if (mounted) setState(() => _secondsLeft--);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إعدادات الأذان والمنبه'), backgroundColor: const Color(0xFF162D25)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SwitchListTile(
            title: const Text('تفعيل تنبيه الأذان الصوتي'),
            subtitle: const Text('تشغيل صوت الأذان كاملاً عند كل صلاة'),
            value: _isAutoAzanEnabled,
            activeColor: Colors.greenAccent,
            onChanged: (val) => setState(() => _isAutoAzanEnabled = val),
          ),
          const Divider(color: Colors.white24),
          Card(
            color: const Color(0xFF162D25),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('تجربة الأذان الحقيقي والشاشة مقفلة:', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  const Text(
                    'اضغط الزر، ثم أقفل شاشة هاتفك فوراً. بعد 20 ثانية سيعمل الأذان.',
                    style: TextStyle(fontSize: 13, color: Colors.white70),
                  ),
                  const SizedBox(height: 14),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.amber.shade700, foregroundColor: Colors.white),
                    onPressed: _secondsLeft > 0 ? null : _start20SecTest,
                    icon: const Icon(Icons.timer),
                    label: Text(_secondsLeft > 0 ? 'انتظر ($_secondsLeft) ثانية وأقفل الشاشة...' : 'تجربة المنبه بعد 20 ثانية'),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(foregroundColor: Colors.redAccent),
                    onPressed: _stopAzan,
                    icon: const Icon(Icons.stop),
                    label: const Text('إيقاف صوت الأذان'),
                  ),
                ],
              ),
            ),
          ),
          if (_isPlaying) ...[
            const SizedBox(height: 14),
            InkWell(
              onTap: _stopAzan,
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.red.shade900, borderRadius: BorderRadius.circular(8)),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.volume_up, color: Colors.white),
                    SizedBox(width: 8),
                    Text('الأذان يعمل الآن - المس هنا للإيقاف', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ),
          ]
        ],
      ),
    );
  }
}

class SebhaScreen extends StatefulWidget {
  const SebhaScreen({super.key});

  @override
  State<SebhaScreen> createState() => _SebhaScreenState();
}

class _SebhaScreenState extends State<SebhaScreen> {
  int _counter = 0;
  final List<String> _azkar = ['سبحان الله', 'الحمد لله', 'لا إله إلا الله', 'الله أكبر'];
  int _selectedZikr = 0;

  void _tap() {
    HapticFeedback.lightImpact();
    setState(() => _counter++);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المسبحة الإلكترونية'), backgroundColor: const Color(0xFF162D25)),
      body: Column(
        children: [
          const SizedBox(height: 14),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: List.generate(_azkar.length, (i) => Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: ChoiceChip(
                  label: Text(_azkar[i]),
                  selected: _selectedZikr == i,
                  onSelected: (val) => setState(() => _selectedZikr = i),
                ),
              )),
            ),
          ),
          const Spacer(),
          Text('$_counter', style: const TextStyle(fontSize: 60, fontWeight: FontWeight.bold, color: Colors.greenAccent)),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: _tap,
            child: Container(
              width: 130,
              height: 130,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.greenAccent, width: 3),
                color: const Color(0xFF1B4332),
              ),
              child: const Icon(Icons.fingerprint, size: 70, color: Colors.greenAccent),
            ),
          ),
          const SizedBox(height: 16),
          TextButton.icon(
            onPressed: () => setState(() => _counter = 0),
            icon: const Icon(Icons.refresh, color: Colors.white70),
            label: const Text('تصفير', style: TextStyle(color: Colors.white70)),
          ),
          const Spacer(),
        ],
      ),
    );
  }
}

class DuasScreen extends StatelessWidget {
  const DuasScreen({super.key});

  final List<String> _duas = const [
    'اللهم ارحم موتانا وموتى المسلمين، واجعل قبورهم روضة من رياض الجنة.',
    'اللهم اغفر لوالدي وارحمه وعافه واعف عنه، واغسله بالماء والثلج والبرد.',
    'ربنا آتنا في الدنيا حسنة وفي الآخرة حسنة وقنا عذاب النار.',
    'لا إله إلا أنت سبحانك إني كنت من الظالمين.'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('أدعية وأذكار'), backgroundColor: const Color(0xFF162D25)),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _duas.length,
        itemBuilder: (ctx, i) => Card(
          color: const Color(0xFF162D25),
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_duas[i], style: const TextStyle(fontSize: 15, height: 1.4)),
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton.icon(
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: _duas[i]));
                      ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('تم نسخ الدعاء')));
                    },
                    icon: const Icon(Icons.copy, size: 16),
                    label: const Text('نسخ'),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class WhatsNewScreen extends StatelessWidget {
  const WhatsNewScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ما الجديد والتنبيهات'), backgroundColor: const Color(0xFF162D25)),
      body: const Padding(
        padding: EdgeInsets.all(16),
        children: [
          Text('أهلاً بكم في تطبيق صلاتي', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          SizedBox(height: 10),
          Text('• نظام تنبيه الأذان الصوتي في الخلفية والجيب.'),
          Text('• شاشة فك قيود البطارية والتشغيل التلقائي لشاشات شاومي.'),
          Text('• المسبحة الإلكترونية التفاعلية.'),
        ],
      ),
    );
  }
}
